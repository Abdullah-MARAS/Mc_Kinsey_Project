#installing packages
library(dplyr)
library(corrplot)
library(car)
library(perturb)
library(MASS)
library(ROCR)
library(pROC)
library(DescTools)
library(gdata)
library(ggplot2)
library(easyGgplot2)
library(gbm)
#library(caret)

#loading the train dataset
insurance_train <- read.csv(file.choose("C:\\Users\\Ashok Chava\\Documents\\Kaggle\\AnalyticsVidhya\\train_ZoGVYWq.csv"),T)
summary(insurance_train)
insurance_test<-read.csv(file.choose("C:\\Users\\Ashok Chava\\Documents\\Kaggle\\AnalyticsVidhya\\test_66516Ee.csv"),T)



#imputing_missing_values and removing id column
in_train_2<-insurance_train %>% mutate_all(~ifelse(is.na(.), median(., na.rm = TRUE), .)) %>% dplyr::select(-id)
test_in_2<-insurance_test %>% mutate_all(~ifelse(is.na(.), median(., na.rm = TRUE), .))
summary(in_train_2)

#using-generalized boosted regression modelling_Model_1
train_boost_1=gbm(renewal ~ ., data = in_train_2,distribution = "bernoulli",n.trees =5000, shrinkage = 0.01, interaction.depth = 4,verbose = TRUE, train.fraction = .75)

pred_boost1<-predict(train_boost_1,n.trees=5000,type="response")
table(in_train_2$renewal, pred_boost1 > 0.5)
roc_obj_train <- roc(in_train_2$renewal, pred_boost1)
auc(roc_obj_train)
summary(train_boost_1)

pred_boost_test<-predict(train_boost_1,newdata=test_in_2,n.trees=5000,type="response")
output <- cbind(test_in_2, pred_boost_test)
write.csv(output,'testdata_prediction.csv')

#using-generalized boosted regression modelling_Model_2_final_for_this_submission
in_train_2$late<-0
in_train_2$latesum<-in_train_2$Count_3.6_months_late+in_train_2$Count_6.12_months_late+in_train_2$Count_more_than_12_months_late
in_train_2$late[which(in_train_2$latesum>0)]<-1
in_train_2$count_3<-log(in_train_2$Count_3.6_months_late+1)
in_train_2$count_6<-log(in_train_2$Count_6.12_months_late+1)
in_train_2$count_12<-log(in_train_2$Count_more_than_12_months_late+1)
in_train_2$perc_prem<-log(in_train_2$perc_premium_paid_by_cash_credit+1)
in_train_2$Income_log<-log(in_train_2$Income)
in_train_2$age_log<-log(in_train_2$age_in_days)
in_train_2$uw_score_log<-log(in_train_2$application_underwriting_score)
summary(in_train_2)
train_boost_1=gbm(renewal ~ perc_premium_paid_by_cash_credit+count_3+count_6+count_12+Income_log+age_log+uw_score_log+late+no_of_premiums_paid+sourcing_channel+premium+residence_area_type, data = in_train_2,distribution = "bernoulli",n.trees =5000, shrinkage = 0.01, interaction.depth = 4,verbose = TRUE, train.fraction = .75)

pred_boost1<-predict(train_boost_1,n.trees=5000,type="response")
table(in_train_2$renewal, pred_boost1 > 0.5)
roc_obj_train <- roc(in_train_2$renewal, pred_boost1)
auc(roc_obj_train)
summary(train_boost_1)

test_in_2$late<-0
test_in_2$latesum<-test_in_2$Count_3.6_months_late+test_in_2$Count_6.12_months_late+test_in_2$Count_more_than_12_months_late
test_in_2$late[which(test_in_2$latesum>0)]<-1
test_in_2$count_3<-log(test_in_2$Count_3.6_months_late+1)
test_in_2$count_6<-log(test_in_2$Count_6.12_months_late+1)
test_in_2$count_12<-log(test_in_2$Count_more_than_12_months_late+1)
test_in_2$perc_prem<-log(test_in_2$perc_premium_paid_by_cash_credit+1)
test_in_2$Income_log<-log(test_in_2$Income)
test_in_2$age_log<-log(test_in_2$age_in_days)
test_in_2$uw_score_log<-log(test_in_2$application_underwriting_score)

pred_boost_test<-predict(train_boost_1,newdata=test_in_2,n.trees=5000,type="response")
output <- cbind(test_in_2, pred_boost_test)
write.csv(output,'testdata_prediction_2.csv')

